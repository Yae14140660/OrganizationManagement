Page({
  data:{

  },

  clickButton(){
    wx.navigateTo({
      url: '../vote_edit/vote_edit',
    })
  }
})